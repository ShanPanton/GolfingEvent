﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGolfer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cboLastName = New System.Windows.Forms.ComboBox()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblCity = New System.Windows.Forms.Label()
        Me.lblState = New System.Windows.Forms.Label()
        Me.lblZip = New System.Windows.Forms.Label()
        Me.lblPhoneNumber = New System.Windows.Forms.Label()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.txtState = New System.Windows.Forms.TextBox()
        Me.txtZip = New System.Windows.Forms.TextBox()
        Me.txtPhoneNumber = New System.Windows.Forms.TextBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblSelectLastName = New System.Windows.Forms.Label()
        Me.lblShirtSize = New System.Windows.Forms.Label()
        Me.lblGender = New System.Windows.Forms.Label()
        Me.btnAddGolfer = New System.Windows.Forms.Button()
        Me.cboShirtSize = New System.Windows.Forms.ComboBox()
        Me.cboGender = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'cboLastName
        '
        Me.cboLastName.FormattingEnabled = True
        Me.cboLastName.Items.AddRange(New Object() {""})
        Me.cboLastName.Location = New System.Drawing.Point(73, 99)
        Me.cboLastName.Name = "cboLastName"
        Me.cboLastName.Size = New System.Drawing.Size(284, 24)
        Me.cboLastName.TabIndex = 0
        '
        'lblFirstName
        '
        Me.lblFirstName.Location = New System.Drawing.Point(70, 145)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(100, 23)
        Me.lblFirstName.TabIndex = 1
        Me.lblFirstName.Text = "First Name :"
        '
        'lblLastName
        '
        Me.lblLastName.Location = New System.Drawing.Point(70, 184)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(100, 23)
        Me.lblLastName.TabIndex = 2
        Me.lblLastName.Text = "Last Name :"
        '
        'lblAddress
        '
        Me.lblAddress.Location = New System.Drawing.Point(70, 221)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(100, 23)
        Me.lblAddress.TabIndex = 3
        Me.lblAddress.Text = "Address:"
        '
        'lblCity
        '
        Me.lblCity.Location = New System.Drawing.Point(70, 257)
        Me.lblCity.Name = "lblCity"
        Me.lblCity.Size = New System.Drawing.Size(100, 23)
        Me.lblCity.TabIndex = 4
        Me.lblCity.Text = "City :"
        '
        'lblState
        '
        Me.lblState.Location = New System.Drawing.Point(70, 290)
        Me.lblState.Name = "lblState"
        Me.lblState.Size = New System.Drawing.Size(100, 23)
        Me.lblState.TabIndex = 5
        Me.lblState.Text = "State :"
        '
        'lblZip
        '
        Me.lblZip.Location = New System.Drawing.Point(70, 316)
        Me.lblZip.Name = "lblZip"
        Me.lblZip.Size = New System.Drawing.Size(100, 23)
        Me.lblZip.TabIndex = 6
        Me.lblZip.Text = "Zip :"
        '
        'lblPhoneNumber
        '
        Me.lblPhoneNumber.Location = New System.Drawing.Point(70, 342)
        Me.lblPhoneNumber.Name = "lblPhoneNumber"
        Me.lblPhoneNumber.Size = New System.Drawing.Size(100, 39)
        Me.lblPhoneNumber.TabIndex = 7
        Me.lblPhoneNumber.Text = "Phone Number :"
        '
        'lblEmail
        '
        Me.lblEmail.Location = New System.Drawing.Point(70, 384)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(100, 23)
        Me.lblEmail.TabIndex = 8
        Me.lblEmail.Text = "Email :"
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(162, 145)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(166, 22)
        Me.txtFirstName.TabIndex = 9
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(162, 181)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(166, 22)
        Me.txtLastName.TabIndex = 10
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(162, 222)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(166, 22)
        Me.txtAddress.TabIndex = 11
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(162, 258)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(166, 22)
        Me.txtCity.TabIndex = 12
        '
        'txtState
        '
        Me.txtState.Location = New System.Drawing.Point(162, 288)
        Me.txtState.Name = "txtState"
        Me.txtState.Size = New System.Drawing.Size(166, 22)
        Me.txtState.TabIndex = 13
        '
        'txtZip
        '
        Me.txtZip.Location = New System.Drawing.Point(162, 317)
        Me.txtZip.Name = "txtZip"
        Me.txtZip.Size = New System.Drawing.Size(166, 22)
        Me.txtZip.TabIndex = 14
        '
        'txtPhoneNumber
        '
        Me.txtPhoneNumber.Location = New System.Drawing.Point(162, 353)
        Me.txtPhoneNumber.Name = "txtPhoneNumber"
        Me.txtPhoneNumber.Size = New System.Drawing.Size(166, 22)
        Me.txtPhoneNumber.TabIndex = 15
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(162, 384)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(166, 22)
        Me.txtEmail.TabIndex = 16
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(174, 512)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(109, 30)
        Me.btnUpdate.TabIndex = 17
        Me.btnUpdate.Text = "Update Golfer"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(323, 512)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(111, 30)
        Me.btnDelete.TabIndex = 18
        Me.btnDelete.Text = "Delete Golfer"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(471, 512)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(102, 30)
        Me.btnExit.TabIndex = 19
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblSelectLastName
        '
        Me.lblSelectLastName.Location = New System.Drawing.Point(73, 60)
        Me.lblSelectLastName.Name = "lblSelectLastName"
        Me.lblSelectLastName.Size = New System.Drawing.Size(176, 23)
        Me.lblSelectLastName.TabIndex = 20
        Me.lblSelectLastName.Text = "Select Golfer Last Name :"
        '
        'lblShirtSize
        '
        Me.lblShirtSize.Location = New System.Drawing.Point(70, 415)
        Me.lblShirtSize.Name = "lblShirtSize"
        Me.lblShirtSize.Size = New System.Drawing.Size(100, 23)
        Me.lblShirtSize.TabIndex = 21
        Me.lblShirtSize.Text = "Shirt Size :"
        '
        'lblGender
        '
        Me.lblGender.Location = New System.Drawing.Point(70, 446)
        Me.lblGender.Name = "lblGender"
        Me.lblGender.Size = New System.Drawing.Size(100, 23)
        Me.lblGender.TabIndex = 23
        Me.lblGender.Text = "Gender :"
        '
        'btnAddGolfer
        '
        Me.btnAddGolfer.Location = New System.Drawing.Point(29, 512)
        Me.btnAddGolfer.Name = "btnAddGolfer"
        Me.btnAddGolfer.Size = New System.Drawing.Size(104, 30)
        Me.btnAddGolfer.TabIndex = 25
        Me.btnAddGolfer.Text = "Add Golfer"
        Me.btnAddGolfer.UseVisualStyleBackColor = True
        '
        'cboShirtSize
        '
        Me.cboShirtSize.FormattingEnabled = True
        Me.cboShirtSize.Location = New System.Drawing.Point(162, 415)
        Me.cboShirtSize.Name = "cboShirtSize"
        Me.cboShirtSize.Size = New System.Drawing.Size(166, 24)
        Me.cboShirtSize.TabIndex = 51
        '
        'cboGender
        '
        Me.cboGender.FormattingEnabled = True
        Me.cboGender.Location = New System.Drawing.Point(162, 445)
        Me.cboGender.Name = "cboGender"
        Me.cboGender.Size = New System.Drawing.Size(166, 24)
        Me.cboGender.TabIndex = 52
        '
        'frmGolfer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(598, 575)
        Me.Controls.Add(Me.cboGender)
        Me.Controls.Add(Me.cboShirtSize)
        Me.Controls.Add(Me.btnAddGolfer)
        Me.Controls.Add(Me.lblGender)
        Me.Controls.Add(Me.lblShirtSize)
        Me.Controls.Add(Me.lblSelectLastName)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.txtPhoneNumber)
        Me.Controls.Add(Me.txtZip)
        Me.Controls.Add(Me.txtState)
        Me.Controls.Add(Me.txtCity)
        Me.Controls.Add(Me.txtAddress)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.lblEmail)
        Me.Controls.Add(Me.lblPhoneNumber)
        Me.Controls.Add(Me.lblZip)
        Me.Controls.Add(Me.lblState)
        Me.Controls.Add(Me.lblCity)
        Me.Controls.Add(Me.lblAddress)
        Me.Controls.Add(Me.lblLastName)
        Me.Controls.Add(Me.lblFirstName)
        Me.Controls.Add(Me.cboLastName)
        Me.Name = "frmGolfer"
        Me.Text = "Golfer"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cboLastName As ComboBox
    Friend WithEvents lblFirstName As Label
    Friend WithEvents lblLastName As Label
    Friend WithEvents lblAddress As Label
    Friend WithEvents lblCity As Label
    Friend WithEvents lblState As Label
    Friend WithEvents lblZip As Label
    Friend WithEvents lblPhoneNumber As Label
    Friend WithEvents lblEmail As Label
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents txtAddress As TextBox
    Friend WithEvents txtCity As TextBox
    Friend WithEvents txtState As TextBox
    Friend WithEvents txtZip As TextBox
    Friend WithEvents txtPhoneNumber As TextBox
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblSelectLastName As Label
    Friend WithEvents lblShirtSize As Label
    Friend WithEvents lblGender As Label
    Friend WithEvents btnAddGolfer As Button
    Friend WithEvents cboShirtSize As ComboBox
    Friend WithEvents cboGender As ComboBox
End Class
