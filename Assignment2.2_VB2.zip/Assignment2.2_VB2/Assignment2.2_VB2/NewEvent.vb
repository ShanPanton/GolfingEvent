﻿

' *****************************************************************************
' Name: Shanique Panton
' Date: 09/07/2020
' Assignment 2
' IT 102-400
' ****************************************************************************
Option Strict On

Public Class frmNewEvent

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        'Closes the form
        Close()

    End Sub


    Private Sub btnAddEvent_Click(sender As Object, e As EventArgs) Handles btnAddEvent.Click

        Dim strSelect As String
        Dim strInsert As String
        Dim intEventYear As Integer = CInt(txtNewYear.Text)
        Dim intNextHighestRecordID As Integer
        Dim cmdSelect As OleDb.OleDbCommand  ' this will be used for our Select statement
        Dim cmdInsert As OleDb.OleDbCommand  'Used as Insert Statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim intRowsAffected As Integer


        Try

            If Validation() = True Then

                If OpenDatabaseConnectionSQLServer() = False Then

                    ' No, warn the user ...
                    MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                        "The application will now close.",
                                        Me.Text + " Error",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error)

                    ' and close the form/application
                    Me.Close()

                End If

                strSelect = "SELECT MAX(intEventYearID) + 1 As intNextHighestRecordID" &
                            " From TEventYears"

                'Execute Command
                cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                drSourceTable = cmdSelect.ExecuteReader

                'Read Reasult Highest ID
                drSourceTable.Read()

                'Null?(empty table)
                If drSourceTable.IsDBNull(0) = True Then
                    'Yes,starting at number 1
                    intNextHighestRecordID = 1
                Else
                    'No, Get the next highest ID
                    intNextHighestRecordID = CInt(drSourceTable.Item(0))
                End If

                strInsert = "Insert into TEventYears (intEventYearID, intEventYear )" &
                            " Values (" & intNextHighestRecordID & ",'" & intEventYear & "')"

                MessageBox.Show(strInsert)

                cmdInsert = New OleDb.OleDbCommand(strInsert, m_conAdministrator)

                intRowsAffected = cmdInsert.ExecuteNonQuery

                If intRowsAffected > 0 Then
                    MessageBox.Show("Event Year has been added.")
                    Me.Close()

                End If

                CloseDatabaseConnection()

            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Public Function Validation() As Boolean

        ' loop through the textboxes and check to make sure there is data in them
        For Each cntrl As Control In Controls
            If TypeOf cntrl Is TextBox Then
                cntrl.BackColor = Color.White
                If cntrl.Text = String.Empty Then
                    cntrl.BackColor = Color.Yellow
                    cntrl.Focus()
                    Return False
                End If
            End If
        Next

        'every this is good so return true
        Return True

    End Function


End Class