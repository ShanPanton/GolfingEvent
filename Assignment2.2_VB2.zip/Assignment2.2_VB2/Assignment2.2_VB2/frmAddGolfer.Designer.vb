﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddGolfer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblGender = New System.Windows.Forms.Label()
        Me.lblShirtSize = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnAddGolfer = New System.Windows.Forms.Button()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtPhoneNumber = New System.Windows.Forms.TextBox()
        Me.txtZip = New System.Windows.Forms.TextBox()
        Me.txtState = New System.Windows.Forms.TextBox()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.lblPhoneNumber = New System.Windows.Forms.Label()
        Me.lblZip = New System.Windows.Forms.Label()
        Me.lblState = New System.Windows.Forms.Label()
        Me.lblCity = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.cboShirtSize = New System.Windows.Forms.ComboBox()
        Me.cboGender = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'lblGender
        '
        Me.lblGender.Location = New System.Drawing.Point(59, 366)
        Me.lblGender.Name = "lblGender"
        Me.lblGender.Size = New System.Drawing.Size(100, 23)
        Me.lblGender.TabIndex = 48
        Me.lblGender.Text = "Gender :"
        '
        'lblShirtSize
        '
        Me.lblShirtSize.Location = New System.Drawing.Point(59, 339)
        Me.lblShirtSize.Name = "lblShirtSize"
        Me.lblShirtSize.Size = New System.Drawing.Size(100, 23)
        Me.lblShirtSize.TabIndex = 46
        Me.lblShirtSize.Text = "Shirt Size :"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(275, 435)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 30)
        Me.btnExit.TabIndex = 44
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnAddGolfer
        '
        Me.btnAddGolfer.Location = New System.Drawing.Point(84, 435)
        Me.btnAddGolfer.Name = "btnAddGolfer"
        Me.btnAddGolfer.Size = New System.Drawing.Size(75, 30)
        Me.btnAddGolfer.TabIndex = 42
        Me.btnAddGolfer.Text = "Add Golfer"
        Me.btnAddGolfer.UseVisualStyleBackColor = True
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(151, 308)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(166, 22)
        Me.txtEmail.TabIndex = 41
        '
        'txtPhoneNumber
        '
        Me.txtPhoneNumber.Location = New System.Drawing.Point(151, 277)
        Me.txtPhoneNumber.Name = "txtPhoneNumber"
        Me.txtPhoneNumber.Size = New System.Drawing.Size(166, 22)
        Me.txtPhoneNumber.TabIndex = 40
        '
        'txtZip
        '
        Me.txtZip.Location = New System.Drawing.Point(151, 241)
        Me.txtZip.Name = "txtZip"
        Me.txtZip.Size = New System.Drawing.Size(166, 22)
        Me.txtZip.TabIndex = 39
        '
        'txtState
        '
        Me.txtState.Location = New System.Drawing.Point(151, 212)
        Me.txtState.Name = "txtState"
        Me.txtState.Size = New System.Drawing.Size(166, 22)
        Me.txtState.TabIndex = 38
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(151, 182)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(166, 22)
        Me.txtCity.TabIndex = 37
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(151, 146)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(166, 22)
        Me.txtAddress.TabIndex = 36
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(151, 105)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(166, 22)
        Me.txtLastName.TabIndex = 35
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(151, 69)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(166, 22)
        Me.txtFirstName.TabIndex = 34
        '
        'lblEmail
        '
        Me.lblEmail.Location = New System.Drawing.Point(59, 308)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(100, 23)
        Me.lblEmail.TabIndex = 33
        Me.lblEmail.Text = "Email :"
        '
        'lblPhoneNumber
        '
        Me.lblPhoneNumber.Location = New System.Drawing.Point(59, 266)
        Me.lblPhoneNumber.Name = "lblPhoneNumber"
        Me.lblPhoneNumber.Size = New System.Drawing.Size(100, 39)
        Me.lblPhoneNumber.TabIndex = 32
        Me.lblPhoneNumber.Text = "Phone Number :"
        '
        'lblZip
        '
        Me.lblZip.Location = New System.Drawing.Point(59, 240)
        Me.lblZip.Name = "lblZip"
        Me.lblZip.Size = New System.Drawing.Size(100, 23)
        Me.lblZip.TabIndex = 31
        Me.lblZip.Text = "Zip :"
        '
        'lblState
        '
        Me.lblState.Location = New System.Drawing.Point(59, 214)
        Me.lblState.Name = "lblState"
        Me.lblState.Size = New System.Drawing.Size(100, 23)
        Me.lblState.TabIndex = 30
        Me.lblState.Text = "State :"
        '
        'lblCity
        '
        Me.lblCity.Location = New System.Drawing.Point(59, 181)
        Me.lblCity.Name = "lblCity"
        Me.lblCity.Size = New System.Drawing.Size(100, 23)
        Me.lblCity.TabIndex = 29
        Me.lblCity.Text = "City :"
        '
        'lblAddress
        '
        Me.lblAddress.Location = New System.Drawing.Point(59, 145)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(100, 23)
        Me.lblAddress.TabIndex = 28
        Me.lblAddress.Text = "Address:"
        '
        'lblLastName
        '
        Me.lblLastName.Location = New System.Drawing.Point(59, 108)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(100, 23)
        Me.lblLastName.TabIndex = 27
        Me.lblLastName.Text = "Last Name :"
        '
        'lblFirstName
        '
        Me.lblFirstName.Location = New System.Drawing.Point(59, 69)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(100, 23)
        Me.lblFirstName.TabIndex = 26
        Me.lblFirstName.Text = "First Name :"
        '
        'cboShirtSize
        '
        Me.cboShirtSize.FormattingEnabled = True
        Me.cboShirtSize.Location = New System.Drawing.Point(151, 336)
        Me.cboShirtSize.Name = "cboShirtSize"
        Me.cboShirtSize.Size = New System.Drawing.Size(166, 24)
        Me.cboShirtSize.TabIndex = 50
        '
        'cboGender
        '
        Me.cboGender.FormattingEnabled = True
        Me.cboGender.Location = New System.Drawing.Point(151, 363)
        Me.cboGender.Name = "cboGender"
        Me.cboGender.Size = New System.Drawing.Size(166, 24)
        Me.cboGender.TabIndex = 51
        '
        'frmAddGolfer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(473, 529)
        Me.Controls.Add(Me.cboGender)
        Me.Controls.Add(Me.cboShirtSize)
        Me.Controls.Add(Me.lblGender)
        Me.Controls.Add(Me.lblShirtSize)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnAddGolfer)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.txtPhoneNumber)
        Me.Controls.Add(Me.txtZip)
        Me.Controls.Add(Me.txtState)
        Me.Controls.Add(Me.txtCity)
        Me.Controls.Add(Me.txtAddress)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.lblEmail)
        Me.Controls.Add(Me.lblPhoneNumber)
        Me.Controls.Add(Me.lblZip)
        Me.Controls.Add(Me.lblState)
        Me.Controls.Add(Me.lblCity)
        Me.Controls.Add(Me.lblAddress)
        Me.Controls.Add(Me.lblLastName)
        Me.Controls.Add(Me.lblFirstName)
        Me.Name = "frmAddGolfer"
        Me.Text = "frmAddGolfer"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblGender As Label
    Friend WithEvents lblShirtSize As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnAddGolfer As Button
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents txtPhoneNumber As TextBox
    Friend WithEvents txtZip As TextBox
    Friend WithEvents txtState As TextBox
    Friend WithEvents txtCity As TextBox
    Friend WithEvents txtAddress As TextBox
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents lblEmail As Label
    Friend WithEvents lblPhoneNumber As Label
    Friend WithEvents lblZip As Label
    Friend WithEvents lblState As Label
    Friend WithEvents lblCity As Label
    Friend WithEvents lblAddress As Label
    Friend WithEvents lblLastName As Label
    Friend WithEvents lblFirstName As Label
    Friend WithEvents cboShirtSize As ComboBox
    Friend WithEvents cboGender As ComboBox
End Class
