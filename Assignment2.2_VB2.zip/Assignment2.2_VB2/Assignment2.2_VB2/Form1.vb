﻿' *****************************************************************************
' Name: Shanique Panton
' Date: 09/07/2020
' Assignment 2
' IT 102-400
' ****************************************************************************
Option Strict On

Public Class frmMain




    Private Sub btnManageGolfers_Click(sender As Object, e As EventArgs) Handles btnManageGolfers.Click
        'Shows the Golfer Form
        frmGolfer.Show()



    End Sub

    Private Sub btnManageEvents_Click(sender As Object, e As EventArgs) Handles btnManageEvents.Click

        'Shows the Events Form
        frmManageEvent.Show()


    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        'Closes the form
        Close()

    End Sub
End Class
