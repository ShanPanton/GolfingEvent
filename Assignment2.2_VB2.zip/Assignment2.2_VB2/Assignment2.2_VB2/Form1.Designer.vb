﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnManageGolfers = New System.Windows.Forms.Button()
        Me.btnManageEvents = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnManageGolfers
        '
        Me.btnManageGolfers.Location = New System.Drawing.Point(98, 74)
        Me.btnManageGolfers.Name = "btnManageGolfers"
        Me.btnManageGolfers.Size = New System.Drawing.Size(116, 55)
        Me.btnManageGolfers.TabIndex = 0
        Me.btnManageGolfers.Text = "Manage Golfers"
        Me.btnManageGolfers.UseVisualStyleBackColor = True
        '
        'btnManageEvents
        '
        Me.btnManageEvents.Location = New System.Drawing.Point(386, 74)
        Me.btnManageEvents.Name = "btnManageEvents"
        Me.btnManageEvents.Size = New System.Drawing.Size(116, 55)
        Me.btnManageEvents.TabIndex = 1
        Me.btnManageEvents.Text = "Manage Events"
        Me.btnManageEvents.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(242, 175)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(116, 36)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(599, 263)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnManageEvents)
        Me.Controls.Add(Me.btnManageGolfers)
        Me.Name = "frmMain"
        Me.Text = "Main Form"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnManageGolfers As Button
    Friend WithEvents btnManageEvents As Button
    Friend WithEvents btnExit As Button
End Class
